# My Work no Chrome

## Atualizar para a versão 2.2.0

1. Extraia o ZIP em uma pasta permanente.
2. Abra `chrome://extensions` e ative **Modo do desenvolvedor**.
3. Se já usa a uma versão anterior, extraia os arquivos sobre a pasta dela e clique em Recarregar no cartão da extensão. Para uma instalação nova, clique em **Carregar sem compactação** e selecione a pasta `my-work-extension-v2.2` que contém o arquivo `manifest.json`.
4. Fixe a nova extensão no menu de extensões e abra o pop-up pelo ícone.

Se o pop-up pedir login, clique em **Entrar no My Work** e entre com sua conta no mesmo perfil do Chrome. Depois, feche a aba e clique em **Atualizar** no pop-up. Se sua sessão expirar, repita o login.

O pop-up acessa os mesmos chamados e anotações do site e do PWA. Requer internet e Chrome 116 ou posterior.
